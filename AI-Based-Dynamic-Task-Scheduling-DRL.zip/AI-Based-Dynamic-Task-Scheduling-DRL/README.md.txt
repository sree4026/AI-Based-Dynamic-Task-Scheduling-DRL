# AI-Based Dynamic Task Scheduling using DRL

## Requirements

- Java 17
- Maven

## Build

mvn clean install

## Run

```bash
mvn clean install
mvn exec:java