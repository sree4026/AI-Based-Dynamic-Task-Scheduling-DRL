package org.cloudsimplus.drl;

public class SchedulerTest {

    public static void main(String[] args) {

        System.out.println(
            "Scheduler testing completed."
        );
    }
}