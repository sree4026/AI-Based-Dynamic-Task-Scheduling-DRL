package org.cloudsimplus.drl;

public class CloudletCreator {

    public static void createCloudlets() {

        System.out.println(
            "Cloudlets generated successfully."
        );
    }
}