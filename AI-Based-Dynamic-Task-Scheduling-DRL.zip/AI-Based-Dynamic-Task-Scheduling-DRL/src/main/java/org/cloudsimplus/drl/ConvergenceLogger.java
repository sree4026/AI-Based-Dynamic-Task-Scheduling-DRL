package org.cloudsimplus.drl;

import java.io.FileWriter;
import java.io.IOException;

public class ConvergenceLogger {

    public static void logReward(
            int episode,
            double reward)
            throws IOException {

        FileWriter writer =
                new FileWriter(
                        "results/convergence.csv",
                        true);

        writer.write(episode + ","
                + reward + "\n");

        writer.close();
    }
}