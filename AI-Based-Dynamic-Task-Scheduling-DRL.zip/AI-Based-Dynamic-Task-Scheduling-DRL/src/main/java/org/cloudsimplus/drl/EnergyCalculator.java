package org.cloudsimplus.drl;

public class EnergyCalculator {

    public static double calculateEnergy(double utilization) {

        double idlePower = 100;
        double maxPower = 250;

        return idlePower +
                (maxPower - idlePower) * utilization;
    }
}