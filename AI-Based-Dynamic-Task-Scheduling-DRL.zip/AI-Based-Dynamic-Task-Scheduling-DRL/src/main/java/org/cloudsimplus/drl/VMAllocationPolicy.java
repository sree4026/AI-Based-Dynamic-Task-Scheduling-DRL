package org.cloudsimplus.drl;

public class VMAllocationPolicy {

    public static String allocateVM(int taskLength) {

        if(taskLength < 2000)
            return "SMALL_VM";

        else if(taskLength < 3500)
            return "MEDIUM_VM";

        else
            return "LARGE_VM";
    }
}