package org.cloudsimplus.drl;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class DatasetGenerator {

    public static void main(String[] args)
            throws IOException {

        FileWriter writer =
                new FileWriter("dataset/synthetic_dataset.csv");

        writer.write("task_length,priority,deadline\n");

        Random random = new Random();

        for (int i = 0; i < 1000; i++) {

            int length = 1000 + random.nextInt(5000);
            int priority = 1 + random.nextInt(4);
            int deadline = 20 + random.nextInt(80);

            writer.write(length + ","
                    + priority + ","
                    + deadline + "\n");
        }

        writer.close();

        System.out.println("Synthetic Dataset Generated.");
    }
}