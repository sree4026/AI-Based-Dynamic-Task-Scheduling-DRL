package org.cloudsimplus.drl;

public class SLAEvaluator {

    public static double calculateViolation(
            double responseTime,
            double deadline) {

        if(responseTime > deadline)
            return 1.0;

        return 0.0;
    }
}