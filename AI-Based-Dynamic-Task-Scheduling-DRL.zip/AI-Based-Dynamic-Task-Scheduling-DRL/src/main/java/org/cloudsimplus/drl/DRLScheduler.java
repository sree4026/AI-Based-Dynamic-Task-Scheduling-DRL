package org.cloudsimplus.drl;

import org.cloudbus.cloudsim.cloudlets.Cloudlet;
import org.cloudbus.cloudsim.vms.Vm;

import java.util.List;

public class DRLScheduler {

    private final List<Vm> vmList;

    public DRLScheduler(List<Vm> vmList) {
        this.vmList = vmList;
    }

    public Vm selectVm(Cloudlet cloudlet) {

        Vm bestVm = vmList.get(0);

        double minLoad = Double.MAX_VALUE;

        for (Vm vm : vmList) {

            double load = vm.getCpuPercentUtilization();

            if (load < minLoad) {
                minLoad = load;
                bestVm = vm;
            }
        }

        return bestVm;
    }
}