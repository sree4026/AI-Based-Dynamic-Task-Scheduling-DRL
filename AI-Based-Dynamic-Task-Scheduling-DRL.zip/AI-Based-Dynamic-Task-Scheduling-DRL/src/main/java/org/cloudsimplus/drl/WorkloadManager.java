package org.cloudsimplus.drl;

import java.util.Random;

public class WorkloadManager {

    private final Random random = new Random();

    public int generateTaskLength() {

        return 1000 + random.nextInt(5000);
    }
}