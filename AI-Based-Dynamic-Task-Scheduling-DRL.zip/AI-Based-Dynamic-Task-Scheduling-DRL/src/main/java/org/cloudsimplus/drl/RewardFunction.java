package org.cloudsimplus.drl;

public class RewardFunction {

    public static double calculateReward(
            double makespan,
            double energy,
            double slaViolation) {

        double alpha = 0.5;
        double beta = 0.3;
        double gamma = 0.2;

        return -(alpha * makespan
                + beta * energy
                + gamma * slaViolation);
    }
}