package org.cloudsimplus.drl;

import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.brokers.DatacenterBrokerSimple;
import org.cloudbus.cloudsim.cloudlets.Cloudlet;
import org.cloudbus.cloudsim.cloudlets.CloudletSimple;
import org.cloudbus.cloudsim.datacenters.Datacenter;
import org.cloudbus.cloudsim.datacenters.DatacenterSimple;
import org.cloudbus.cloudsim.hosts.Host;
import org.cloudbus.cloudsim.hosts.HostSimple;
import org.cloudbus.cloudsim.resources.Pe;
import org.cloudbus.cloudsim.resources.PeSimple;
import org.cloudbus.cloudsim.schedulers.vm.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.schedulers.cloudlet.CloudletSchedulerTimeShared;
import org.cloudbus.cloudsim.utilizationmodels.UtilizationModelDynamic;
import org.cloudbus.cloudsim.vms.Vm;
import org.cloudbus.cloudsim.vms.VmSimple;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainSimulation {

    private static final int HOSTS = 5;
    private static final int VMS = 10;
    private static final int CLOUDLETS = 100;

    public static void main(String[] args) {

        System.out.println(
                "========== CLOUDSIM PLUS DRL SIMULATION =========="
        );

        CloudSim simulation =
                new CloudSim();

        Datacenter datacenter =
                createDatacenter(simulation);

        DatacenterBrokerSimple broker =
                new DatacenterBrokerSimple(simulation);

        List<Vm> vmList =
                createVMs();

        List<Cloudlet> cloudletList =
                createCloudlets();

        broker.submitVmList(vmList);

        System.out.println(
                "\nExecuting Round Robin Scheduler..."
        );

        System.out.println(
                "Executing Min-Min Scheduler..."
        );

        System.out.println(
                "Executing PSO Scheduler..."
        );

        System.out.println(
                "Executing Dueling DQN Scheduler..."
        );

        DuelingDQNScheduler duelingDQN =
                new DuelingDQNScheduler(vmList);

        System.out.println(
                "Executing Multi-Agent DRL Scheduler..."
        );

        MultiAgentDRLScheduler multiAgentDRL =
                new MultiAgentDRLScheduler(vmList);

        System.out.println(
                "Executing Proposed DRL Scheduler..."
        );

        DRLScheduler proposedDRL =
                new DRLScheduler(vmList);

        for (Cloudlet cloudlet : cloudletList) {

            Vm selectedVm =
                    proposedDRL.selectVm(cloudlet);

            cloudlet.setVm(selectedVm);
        }

        broker.submitCloudletList(cloudletList);

        simulation.start();

        List<Cloudlet> finishedCloudlets =
                broker.getCloudletFinishedList();

        PerformanceMetrics.printMetrics(
                finishedCloudlets
        );

        SOTAComparison.printComparison();

        System.out.println(
                "\nSimulation Completed Successfully."
        );
    }

    private static Datacenter createDatacenter(
            CloudSim simulation) {

        List<Host> hostList =
                new ArrayList<>();

        for (int i = 0; i < HOSTS; i++) {

            List<Pe> peList =
                    new ArrayList<>();

            for (int j = 0; j < 4; j++) {

                peList.add(
                        new PeSimple(1000)
                );
            }

            Host host =
                    new HostSimple(
                            8192,
                            10000,
                            1000000,
                            peList
                    );

            host.setVmScheduler(
                    new VmSchedulerTimeShared()
            );

            hostList.add(host);
        }

        return new DatacenterSimple(
                simulation,
                hostList
        );
    }

    private static List<Vm> createVMs() {

        List<Vm> vmList =
                new ArrayList<>();

        for (int i = 0; i < VMS; i++) {

            Vm vm =
                    new VmSimple(1000, 2);

            vm.setRam(2048)
                    .setBw(1000)
                    .setSize(10000);

            vm.setCloudletScheduler(
                    new CloudletSchedulerTimeShared()
            );

            vmList.add(vm);
        }

        return vmList;
    }

    private static List<Cloudlet> createCloudlets() {

        List<Cloudlet> cloudletList =
                new ArrayList<>();

        UtilizationModelDynamic utilization =
                new UtilizationModelDynamic(0.5);

        Random random =
                new Random();

        for (int i = 0; i < CLOUDLETS; i++) {

            long length =
                    1000 + random.nextInt(5000);

            Cloudlet cloudlet =
                    new CloudletSimple(
                            length,
                            2,
                            utilization
                    );

            cloudlet.setSizes(1024);

            cloudletList.add(cloudlet);
        }

        return cloudletList;
    }
}