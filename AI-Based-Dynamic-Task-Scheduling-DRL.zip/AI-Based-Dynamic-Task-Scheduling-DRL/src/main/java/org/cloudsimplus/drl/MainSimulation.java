package org.cloudsimplus.drl;
            List<Pe> peList = new ArrayList<>();

            for (int j = 0; j < 4; j++) {
                peList.add(new PeSimple(1000));
            }

            Host host = new HostSimple(
                    8192,
                    10000,
                    1000000,
                    peList
            );

            host.setVmScheduler(new VmSchedulerTimeShared());

            hostList.add(host);
        }

        return new DatacenterSimple(simulation, hostList);
    }

    private static List<Vm> createVms() {

        List<Vm> vmList = new ArrayList<>();

        for (int i = 0; i < VMS; i++) {

            Vm vm = new VmSimple(1000, 2);

            vm.setRam(2048)
              .setBw(1000)
              .setSize(10000);

            vm.setCloudletScheduler(
                    new CloudletSchedulerTimeShared()
            );

            vmList.add(vm);
        }

        return vmList;
    }

    private static List<Cloudlet> createCloudlets() {

        List<Cloudlet> cloudletList = new ArrayList<>();

        UtilizationModelDynamic utilization =
                new UtilizationModelDynamic(0.5);

        Random random = new Random();

        for (int i = 0; i < CLOUDLETS; i++) {

            long length = 1000 + random.nextInt(5000);

            Cloudlet cloudlet = new CloudletSimple(
                    length,
                    2,
                    utilization
            );

            cloudlet.setSizes(1024);

            cloudletList.add(cloudlet);
        }

        return cloudletList;
    }
}